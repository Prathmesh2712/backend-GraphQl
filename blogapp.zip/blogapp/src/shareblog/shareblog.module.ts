import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedBlog } from './shareblog/shareblog.entity';
import { ShareblogResolver } from './shareblog/shareblog.resolver';
import { ShareblogService } from './shareblog/shareblog.service';

@Module({
  imports: [TypeOrmModule.forFeature([SharedBlog])],
  controllers: [],
  providers: [ShareblogService, ShareblogResolver],
})
export class ShareblogModule {}
