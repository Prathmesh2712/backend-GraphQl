import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SharedBlog } from './shareblog.entity';

@Injectable()
export class ShareblogService {
  constructor(
    @InjectRepository(SharedBlog)
    private repository: Repository<SharedBlog>,
    private jwtService: JwtService,
  ) {}
  async shareBlog(blog_id: number, shared_with_user_email: string, token) {
    try {
      const decodedToken = this.jwtService.verify(token);
      const shared_by_user_email = decodedToken.email;

      const blog = new SharedBlog();
      blog.blog_id = blog_id;
      blog.shared_with_user_email = shared_with_user_email;
      blog.shared_by_user_email = shared_by_user_email;
      console.log('Blog:::', blog);
      await this.repository.save(blog);
      return { status: 'success', data: [blog] };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }

  async viewSharedBlog(token: string) {
    try {
      const decodedToken = this.jwtService.verify(token);
      const sharedWithUserEmail = decodedToken.email;

      const sharedBlogs = await this.repository
        .createQueryBuilder('sb')
        .leftJoinAndSelect('sb.blog', 'blog')
        .select([
          'sb.id as id',
          'sb.blog_id as blog_id',
          'sb.shared_with_user_email as shared_with_user_email',
          'sb.shared_by_user_email as shared_by_user_email',
          'blog.title as title',
          'blog.category as category',
          "DATE_FORMAT(blog.createdTimestamp, '%e %b %Y') as createdTimestamp",
        ])
        .where('sb.shared_with_user_email = :email', {
          email: sharedWithUserEmail,
        })
        .getRawMany();
      // .createQueryBuilder('sb')
      // .where('sb.shared_with_user_email = :email', {
      //   email: sharedWithUserEmail,
      // })
      // .getMany();
      console.log(sharedBlogs);
      return { status: 'success', data: sharedBlogs };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }
}
