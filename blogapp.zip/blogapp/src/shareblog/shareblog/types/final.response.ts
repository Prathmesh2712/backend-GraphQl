import { Field, ObjectType } from '@nestjs/graphql';
import { SharedBlogResponse } from './shareblog.responce';

@ObjectType()
export class FinalResponse {
  @Field()
  status: string;

  @Field(() => [SharedBlogResponse], { nullable: true })
  data: [SharedBlogResponse];
}
