import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class SharedBlog {
  @Field()
  id: number;

  @Field()
  blog_id: number;

  @Field()
  shared_with_user_email: string;

  

  @Field()
  shared_by_user_email: string;
}
