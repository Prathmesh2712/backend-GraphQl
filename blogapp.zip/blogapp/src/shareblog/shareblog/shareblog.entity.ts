import { Blog } from 'src/blog/blog/blog.entity';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { User } from '../../user/user/user.entity';

@Entity('shared_blogs')
export class SharedBlog {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  blog_id: number;

  @Column()
  shared_with_user_email: string;

  @Column()
  shared_by_user_email: string;

  @ManyToOne(() => Blog)
  @JoinColumn({ name: 'blog_id' })
  blog: Blog;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'shared_with_user_email' })
  sharedWithUser: User;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'shared_by_user_email' })
  sharedByUser: User;
}
