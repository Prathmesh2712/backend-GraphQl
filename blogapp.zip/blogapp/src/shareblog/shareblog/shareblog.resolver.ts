import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { ShareblogService } from './shareblog.service';
import { FinalResponse } from './types/final.response';
import { SharedBlogResponse } from './types/shareblog.responce';

@Resolver()
export class ShareblogResolver {
  constructor(private shareblogService: ShareblogService) {}

  @Mutation(() => SharedBlogResponse)
  shareBlog(
    @Args('blog_id') blog_id: number,
    @Args('shared_with_user_email') shared_with_user_email: string,
    @Args('authorization') authorization: string,
  ) {
    return this.shareblogService.shareBlog(
      blog_id,
      shared_with_user_email,
      authorization,
    );
  }

  @Mutation(() => FinalResponse)
  viewSharedBlog(@Args('authorization') authorization: string) {
    return this.shareblogService.viewSharedBlog(authorization);
  }

  @Query(() => SharedBlogResponse)
  view(@Args('authorization') authorization: string) {
    return this.shareblogService.viewSharedBlog(authorization);
  }
}
