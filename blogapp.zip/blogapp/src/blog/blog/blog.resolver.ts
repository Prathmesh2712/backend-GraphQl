import { Args, Mutation, Resolver } from '@nestjs/graphql';
import { BlogService } from './blog.service';
import { BlogResponse } from './types/blog.responce';

@Resolver()
export class BlogResolver {
  constructor(private blogService: BlogService) {}

  @Mutation(() => BlogResponse)
  addingBlog(
    @Args('title') title: string,
    @Args('content') content: string,
    @Args('category') category: string,
    @Args('authorization') authorization: string,
  ) {
    console.log(title);
    // const token = context.req.headers['authorization'];
    // console.log(context);
    return this.blogService.createBlog(title, content, category, authorization);
  }

  @Mutation(() => BlogResponse)
  async getMyblog(@Args('authorization') authorization: string) {
    console.log('inside getMyBlog');
    // const token = context.req.headers['authorization'];
    console.log(
      'in resolver:',
      await this.blogService.getMyBlog(authorization),
    );
    return await this.blogService.getMyBlog(authorization);
  }
  @Mutation(() => BlogResponse)
  getAllBlogs() {
    return this.blogService.getAllBlog();
  }

  @Mutation(() => BlogResponse)
  async getBlogById(@Args('id') id: number) {
    console.log('id is::', id);
    const res = await this.blogService.getBlogById(id);
    console.log('res::', res);
    return res;
  }

  @Mutation(() => BlogResponse)
  updateBlog(
    @Args('id') id: number,
    @Args('title') title: string,
    @Args('content') content: string,
    @Args('category') category: string,
  ) {
    return this.blogService.updateBlog(id, title, content, category);
  }

  @Mutation(() => BlogResponse)
  searchBlog(@Args('text') text: string) {
    console.log('text is::', text);
    return this.blogService.searchBlog(text);
  }

  @Mutation(() => BlogResponse)
  getPublicBlogs() {
    return this.blogService.getPublicBlogs();
  }

  @Mutation(() => BlogResponse)
  setBlogPublic(
    @Args('id') id: number,
    @Args('authorization') authorization: string,
  ) {
    return this.blogService.setBlogPublic(id, authorization);
  }

  @Mutation(() => BlogResponse)
  setBlogPrivate(
    @Args('id') id: number,
    @Args('authorization') authorization: string,
  ) {
    //const token = context.req.headers['authorization'];
    return this.blogService.setBlogPrivate(id, authorization);
  }

  @Mutation(() => BlogResponse)
  deleteBlog(
    @Args('id') id: number,
    @Args('authorization') authorization: string,
  ) {
    return this.blogService.deleteBlog(id, authorization);
  }

  // @Post('share/:id')
  // shareBlog(
  //   @Body('shared_with_user_email') shared_with_user_email: string,
  //   @Headers('token') token: string,
  // ) {
  //   return this.blogService.shareBlog(shared_with_user_email, token);
  // }
}
