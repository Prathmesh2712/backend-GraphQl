import { Field, ObjectType } from '@nestjs/graphql';
import { Blog } from './blog.entry.responce';

@ObjectType()
export class BlogResponse {
  @Field()
  status: string;

  @Field(() => [Blog], { nullable: true })
  data: [Blog];

  @Field(() => Blog, { nullable: true })
  datas: Blog;
}
