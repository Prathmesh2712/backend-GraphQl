import { Field, Int, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class Blog {
  @Field(() => Int)
  id: number;

  @Field({ nullable: true })
  title: string;

  @Field({ nullable: true })
  content: string;

  @Field({ nullable: true })
  category: string;

  @Field({ nullable: true })
  isShared: number;

  @Field({ nullable: true })
  isPublic: number;

  @Field({ nullable: true })
  userId: number;

  @Field({ nullable: true })
  createdTimestamp: Date;
}
