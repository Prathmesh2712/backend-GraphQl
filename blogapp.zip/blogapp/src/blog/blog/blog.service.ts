import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Blog } from './blog.entity';

@Injectable()
export class BlogService {
  constructor(
    @InjectRepository(Blog)
    private repository: Repository<Blog>,
    private jwtService: JwtService,
  ) {}

  async createBlog(
    title: string,
    content: string,
    category: string,
    token: string,
  ) {
    try {
      const decodedToken = this.jwtService.verify(token);
      const userId = decodedToken.id;
      console.log(title, userId);
      const blog = new Blog();
      blog.title = title;
      blog.content = content;
      blog.category = category;
      blog.userId = userId;

      await this.repository.save(blog);
      return { status: 'success', data: 'done' };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }

  //get my blog
  async getMyBlog(token) {
    try {
      const decodedToken = this.jwtService.verify(token);
      const userId = decodedToken.id;

      const result = await this.repository.find({ where: { userId } });
      console.log('result is::', result);
      return { status: 'success', data: result };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }

  async deleteBlog(id, token) {
    try {
      const decodedToken = this.jwtService.verify(token);
      const userId = decodedToken.id;

      const blog = new Blog();
      blog.id = id;
      const blogToRemove = await this.repository.findOne({
        where: { id, userId },
      });
      await this.repository.remove(blogToRemove);
      return { status: 'success', data: 'delete successfully' };
    } catch (ex) {
      return { status: 'error', data: ex };
    }
  }

  async updateBlog(
    id: number,
    title: string,
    content: string,
    category: string,
  ) {
    console.log('inside update');
    console.log(id, title, content, category);
    try {
      const blog = new Blog();
      blog.title = title;
      blog.content = content;
      blog.category = category;

      const result = await this.repository.update(id, blog);
      return { status: 'success', data: 'update done' };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }

  async searchBlog(text: string) {
    try {
      console.log('In service of search');
      const blog = await this.repository
        .createQueryBuilder('blog')
        .select(['blog.id', 'blog.title', 'blog.content', 'blog.category'])
        .where('blog.title LIKE :text', { text: `%${text}%` })
        .getMany();

      return { status: 'success', data: blog };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex.message };
    }
  }

  async getBlogById(id: number) {
    {
      try {
        const result = await this.repository.findOne({ where: { id } });
        console.log('blog in service::', result);
        return { status: 'success', data: [result] };
      } catch (ex) {
        return { status: 'error', error: ex.message };
      }
    }
  }
  async getPublicBlogs() {
    try {
      const blogs = await this.repository.find({ where: { isPublic: 1 } });
      return { status: 'success', data: blogs };
    } catch (ex) {
      return { status: 'error', error: ex.message };
    }
  }

  async setBlogPublic(id: number, token: string) {
    try {
      console.log('inside a setpublicblog::', id);
      const decodedToken = this.jwtService.verify(token);
      const userId = decodedToken.id;
      console.log(id, userId);

      await this.repository.update({ id, userId }, { isPublic: 1 });
      const result = await this.repository.findOne({ where: { id } });
      console.log('result in public block::', result);
      return { status: 'success', data: result };
    } catch (ex) {
      return { status: ex, error: ex };
    }
  }

  async setBlogPrivate(id: number, token: string) {
    try {
      const decodedToken = this.jwtService.verify(token);
      const userId = decodedToken.id;
      await this.repository.update({ id, userId }, { isPublic: 0 });
      const result = await this.repository.findOne({ where: { id } });
      console.log('result in private block::', result);
      return { status: 'success', data: result };
    } catch (ex) {
      return { status: 'error', error: ex.message };
    }
  }

  async getAllBlog() {
    try {
      const result = await this.repository.find();

      return { status: 'success', data: result };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }
}
