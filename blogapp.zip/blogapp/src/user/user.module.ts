import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './user/user.entity';
import { UserResolver } from './user/user.resolver';
import { UserService } from './user/user.service';
@Module({
  imports: [
    // list the entities in this module
    TypeOrmModule.forFeature([User]),

    JwtModule.register({
      global: true,
      secret: '5OWQacPYWUGaufwDJxGnK7DaQKAYjxNQ',
    }),
  ],
  providers: [UserService, UserResolver],
  controllers: [],
})
export class UserModule {}
