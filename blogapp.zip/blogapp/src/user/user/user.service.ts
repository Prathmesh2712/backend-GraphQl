import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';
const cryptoJs = require('crypto-js');

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private repository: Repository<User>,
    private jwtService: JwtService,
  ) {}

  async createUser(
    email: String,
    password: String,
    fullName: String,
    phoneNo: String,
  ) {
    try {
      const encryptedPassword = String(cryptoJs.SHA256(password.toString()));
      // create a row by creating an object of entity class
      const user = new User();

      user.email = email;
      user.password = encryptedPassword;
      user.fullName = fullName;
      user.phoneNo = phoneNo;
      await this.repository.save(user);
      return { status: 'success', data: 'done' };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }

  async login(email: String, password: String) {
    try {
      const encryptedPassword = String(cryptoJs.SHA256(password.toString()));
      const user = await this.repository.findOneBy({
        email,
        password: encryptedPassword,
      });

      if (!user) {
        return { status: 'error', error: 'user does not exist' };
      } else {
        //define payload

        const payload = {
          id: user.id,
          email: `${user.email}`,
        };

        const token = this.jwtService.sign(payload);
        console.log(token);
        return {
          status: 'success',
          token,
          email: user.email,
          id: user.id,
        };
      }
    } catch (ex) {
      return { status: 'error', error: ex };
    }
  }

  async getEmail() {
    try {
      const users = await this.repository.find();
      console.log(users);
      const email = users.map((user) => user.email);
      console.log(email);
      return { status: 'success', data: email };
    } catch (ex) {
      console.log(ex);
      return ex;
    }
  }

  async getUserDetails(token: string) {
    try {
      const decodedToken = this.jwtService.verify(token);
      console.log('decoded::', decodedToken);
      const id = decodedToken.id;
      console.log('id::', id);
      const result = await this.repository.find({ where: { id } });
      console.log('Result::', result);
      return { status: 'success', data: result };
    } catch (ex) {
      console.log(ex);
      return { status: 'error', error: ex };
    }
  }
}
