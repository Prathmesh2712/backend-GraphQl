import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('user')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  email: String;
  @Column()
  password: String;
  @Column()
  fullName: String;
  @Column()
  phoneNo: String;
}
