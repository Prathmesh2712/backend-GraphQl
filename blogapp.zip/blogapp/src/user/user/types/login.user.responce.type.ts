import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class LoginResponseType {
  @Field()
  status: string;

  @Field({ nullable: true }) // Make token nullable
  token: string;

  @Field({ nullable: true }) // Make email nullable
  id: number;

  @Field({ nullable: true }) // Make email nullable
  email: string;

  @Field({ nullable: true }) // Make email nullable
  phoneNo: string;

  @Field({ nullable: true }) // Make email nullable
  fullName: string;

  @Field({ nullable: true })
  error: string;
}
