import { Field, ObjectType } from '@nestjs/graphql';
import { LoginResponseType } from './login.user.responce.type';
@ObjectType()
export class getUserdetailsResponse {
  @Field()
  status: string;

  @Field(() => [LoginResponseType], { nullable: true })
  data: [LoginResponseType];
}
