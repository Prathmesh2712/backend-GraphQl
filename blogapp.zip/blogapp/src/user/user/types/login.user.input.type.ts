// login.input.type.ts
import { Field, InputType } from '@nestjs/graphql';

@InputType()
export class LoginInputType {
  @Field()
  email: string;

  @Field()
  password: string;

  @Field()
  phoneNo: string;

  @Field()
  fullName: string;
}
