import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class EmailResponse {
  @Field()
  status: string;

  @Field(() => [String], { nullable: true }) // Define array of strings for emails
  data: string[];
}
