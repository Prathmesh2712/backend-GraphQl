import { Args, Mutation, Resolver } from '@nestjs/graphql';
import { EmailResponse } from './types/email.responce';
import { getUserdetailsResponse } from './types/getUserdetails.response';
import { LoginResponseType } from './types/login.user.responce.type';
import { UserType } from './types/user.type';
import { UserService } from './user.service';

@Resolver(() => UserType)
export class UserResolver {
  constructor(private userService: UserService) {}

  @Mutation(() => LoginResponseType)
  registerUser(
    @Args('email') firstName: String,
    @Args('password') lastName: String,
    @Args('fullName') email: String,
    @Args('phoneNo') password: String,
  ) {
    return this.userService.createUser(firstName, lastName, email, password);
  }

  @Mutation(() => LoginResponseType)
  loginUser(@Args(`email`) email: String, @Args(`password`) password: String) {
    return this.userService.login(email, password);
  }

  @Mutation(() => EmailResponse)
  async getEmail() {
    const email = await this.userService.getEmail();
    console.log(email);
    return email;
  }

  @Mutation(() => getUserdetailsResponse)
  async getUserDetails(@Args('authorization') authorization: string) {
    const user = this.userService.getUserDetails(authorization);
    return user;
  }
  // @Query(() => LoginResponseType)
  // async getDetails(@Args('authorization') authorization: string) {
  //   const user = this.userService.getUserDetails(authorization);
  //   return user;
  // }
}
